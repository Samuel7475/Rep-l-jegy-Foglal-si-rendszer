from abc import ABC, abstractmethod

class Jarat(ABC):
    def __init__(self, jaratszam, celallomas, jegyar):
        self.jaratszam = jaratszam
        self.celallomas = celallomas
        self.jegyar = jegyar

    @abstractmethod
    def jarat_tipus(self):
        pass

class BelfoldiJarat(Jarat):
    def jarat_tipus(self):
        return "Belföldi"

class NemzetkoziJarat(Jarat):
    def jarat_tipus(self):
        return "Nemzetközi"

class LegiTarsasag:
    def __init__(self, nev):
        self.nev = nev
        self.jaratok = []

    def jarat_hozzaadasa(self, jarat):
        self.jaratok.append(jarat)

    def jarat_keresese(self, jaratszam):
        for jarat in self.jaratok:
            if jarat.jaratszam == jaratszam:
                return jarat
        return None

class JegyFoglalas:
    def __init__(self, utas_nev, jarat):
        self.utas_nev = utas_nev
        self.jarat = jarat

class FoglalasiRendszer:
    def __init__(self):
        self.legi_tarsasag = LegiTarsasag("ChatAir")
        self.foglalasok = []
        self.elotoltes()

    def elotoltes(self):
        j1 = BelfoldiJarat("B101", "Debrecen", 12000)
        j2 = NemzetkoziJarat("N202", "London", 60000)
        j3 = NemzetkoziJarat("N203", "Berlin", 55000)
        self.legi_tarsasag.jarat_hozzaadasa(j1)
        self.legi_tarsasag.jarat_hozzaadasa(j2)
        self.legi_tarsasag.jarat_hozzaadasa(j3)
        self.foglalasok.extend([
            JegyFoglalas("Kovacs Bela", j1),
            JegyFoglalas("Nagy Eva", j2),
            JegyFoglalas("Toth Peter", j3),
            JegyFoglalas("Kiss Anna", j1),
            JegyFoglalas("Varga Zsolt", j2),
            JegyFoglalas("Szabo Lili", j3)
        ])

    def foglalas(self, utas_nev, jaratszam):
        jarat = self.legi_tarsasag.jarat_keresese(jaratszam)
        if jarat:
            foglalas = JegyFoglalas(utas_nev, jarat)
            self.foglalasok.append(foglalas)
            print("Sikeres foglalás: {} -> {}, Ár: {} Ft".format(utas_nev, jarat.celallomas, jarat.jegyar))
        else:
            print("Hiba: Nincs ilyen járatszám.")

    def lemondas(self, utas_nev, jaratszam):
        for f in self.foglalasok:
            if f.utas_nev == utas_nev and f.jarat.jaratszam == jaratszam:
                self.foglalasok.remove(f)
                print("Lemondás sikeres: {} -> {}".format(utas_nev, f.jarat.celallomas))
                return
        print("Hiba: Ilyen foglalás nem található.")

    def listazas(self):
        if not self.foglalasok:
            print("Nincs foglalás.")
        else:
            for f in self.foglalasok:
                print("{} -> {} ({}) - {} Ft".format(
                    f.utas_nev, f.jarat.celallomas, f.jarat.jarat_tipus(), f.jarat.jegyar))

def main():
    rendszer = FoglalasiRendszer()
    while True:
        try:
            print("\n1. Jegy foglalása\n2. Foglalás lemondása\n3. Foglalások listázása\n4. Kilépés")
            valasztas = input("Válassz egy lehetőséget: ")
            if valasztas == "1":
                nev = input("Add meg az utas nevét: ")
                jaratszam = input("Add meg a járatszámot: ")
                rendszer.foglalas(nev, jaratszam)
            elif valasztas == "2":
                nev = input("Add meg az utas nevét: ")
                jaratszam = input("Add meg a járatszámot: ")
                rendszer.lemondas(nev, jaratszam)
            elif valasztas == "3":
                rendszer.listazas()
            elif valasztas == "4":
                print("Kilépés... Viszlát!")
                break
            else:
                print("Hibás választás, próbáld újra.")
        except (EOFError, KeyboardInterrupt):
            print("\nKilépés...")
            break

if __name__ == "__main__":
    main()
